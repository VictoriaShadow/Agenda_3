﻿using Agenda3.Entidades;
using MySql.Data.MySqlClient;
using System.Net;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Agenda3.Datos
{
    public class AgendaDatos
    {
        private string _conexionString = "Server=localhost;Database=agenda;Uid=root;Pwd=;";

        public ObjetoAgenda? BuscarPorDni(string dni)
        {
            string query = "SELECT Dni, Apellido, Nombre, Calle, Depto, Piso, Ciudad, Telefono, Email, CuilCuit, FechaDeAlta, Estado_Civil, Nacionalidad, Provincia, Codigo_Postal, Barrio, Telefono_Alternativo, RedSocial_IG, ProfesionOcupacion, Lugar_Trabajo, Nivel_Estudios, Estado, MetodoPago_Preferido, ObservacionesNotas FROM agenda WHERE dni = @Dni";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Dni", dni);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string dniDb = reader["Dni"].ToString();
                        string apellidoDb = reader["Apellido"].ToString();
                        string nombreDb = reader["Nombre"].ToString();
                        string calleDb = reader["Calle"].ToString();
                        string deptoDb = reader["Depto"].ToString();
                        int pisoDb = Convert.ToInt32(reader["Piso"]);
                        string ciudadDb = reader["Ciudad"].ToString();
                        int telefonoDb = Convert.ToInt32(reader["Telefono"]);
                        string emailDb = reader["Email"].ToString();

                        string CuilCuitDb = reader["CuilCuit"].ToString();
                        string FechaDeAltaDb = reader["FechaDeAlta"].ToString();
                        string Estado_CivilDb = reader["Estado_Civil"].ToString();
                        string NacionalidadDb = reader["Nacionalidad"].ToString();
                        string ProvinciaDb = reader["Provincia"].ToString();
                        int Codigo_PostalDb = Convert.ToInt32(reader["Codigo_Postal"]);
                        string BarrioDb = reader["Barrio"].ToString();
                        int Telefono_AlternativoDb = Convert.ToInt32(reader["Telefono_Alternativo"]);
                        string RedSocial_IGDb = reader["RedSocial_IG"].ToString();
                        string ProfesionOcupacionDb = reader["ProfesionOcupacion"].ToString();
                        string Lugar_TrabajoDb = reader["Lugar_Trabajo"].ToString();
                        string Nivel_EstudiosDb = reader["Nivel_Estudios"].ToString();
                        string EstadoDb = reader["Estado"].ToString();
                        string MetodoPago_PreferidoDb = reader["MetodoPago_Preferido"].ToString();
                        string ObservacionesNotasDb = reader["ObservacionesNotas"].ToString();

                        return new ObjetoAgenda(dniDb, apellidoDb, nombreDb, calleDb, deptoDb, pisoDb, ciudadDb, telefonoDb, emailDb, CuilCuitDb, FechaDeAltaDb, Estado_CivilDb, NacionalidadDb, ProvinciaDb, Codigo_PostalDb, BarrioDb, Telefono_AlternativoDb, RedSocial_IGDb, ProfesionOcupacionDb, Lugar_TrabajoDb, Nivel_EstudiosDb, EstadoDb, MetodoPago_PreferidoDb, ObservacionesNotasDb);
                    }
                }
            }

            return null;
        }

        public ObjetoAgenda? BuscarPorApellido(string apellido)
        {
            string query = "SELECT Dni, Apellido, Nombre, Calle, Depto, Piso, Ciudad, Telefono, Email, CuilCuit, FechaDeAlta, Estado_Civil, Nacionalidad, Provincia, Codigo_Postal, Barrio, Telefono_Alternativo, RedSocial_IG, ProfesionOcupacion, Lugar_Trabajo, Nivel_Estudios, Estado, MetodoPago_Preferido, ObservacionesNotas FROM agenda WHERE apellido = @Apellido";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Apellido", apellido);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string dniDb = reader["Dni"].ToString();
                        string apellidoDb = reader["Apellido"].ToString();
                        string nombreDb = reader["Nombre"].ToString();
                        string calleDb = reader["Calle"].ToString();
                        string deptoDb = reader["Depto"].ToString();
                        int pisoDb = Convert.ToInt32(reader["Piso"]);
                        string ciudadDb = reader["Ciudad"].ToString();
                        int telefonoDb = Convert.ToInt32(reader["Telefono"]);
                        string emailDb = reader["Email"].ToString();

                        string CuilCuitDb = reader["CuilCuit"].ToString();
                        string FechaDeAltaDb = reader["FechaDeAlta"].ToString();
                        string Estado_CivilDb = reader["Estado_Civil"].ToString();
                        string NacionalidadDb = reader["Nacionalidad"].ToString();
                        string ProvinciaDb = reader["Provincia"].ToString();
                        int Codigo_PostalDb = Convert.ToInt32(reader["Codigo_Postal"]);
                        string BarrioDb = reader["Barrio"].ToString();
                        int Telefono_AlternativoDb = Convert.ToInt32(reader["Telefono_Alternativo"]);
                        string RedSocial_IGDb = reader["RedSocial_IG"].ToString();
                        string ProfesionOcupacionDb = reader["ProfesionOcupacion"].ToString();
                        string Lugar_TrabajoDb = reader["Lugar_Trabajo"].ToString();
                        string Nivel_EstudiosDb = reader["Nivel_Estudios"].ToString();
                        string EstadoDb = reader["Estado"].ToString();
                        string MetodoPago_PreferidoDb = reader["MetodoPago_Preferido"].ToString();
                        string ObservacionesNotasDb = reader["ObservacionesNotas"].ToString();

                        return new ObjetoAgenda(dniDb, apellidoDb, nombreDb, calleDb, deptoDb, pisoDb, ciudadDb, telefonoDb, emailDb, CuilCuitDb, FechaDeAltaDb, Estado_CivilDb, NacionalidadDb, ProvinciaDb, Codigo_PostalDb, BarrioDb, Telefono_AlternativoDb, RedSocial_IGDb, ProfesionOcupacionDb, Lugar_TrabajoDb, Nivel_EstudiosDb, EstadoDb, MetodoPago_PreferidoDb, ObservacionesNotasDb);
                    }
                }
            }

            return null;
        }

        public ObjetoAgenda? BuscarPorNombre(string nombre)
        {
            string query = "SELECT Dni, Apellido, Nombre, Calle, Depto, Piso, Ciudad, Telefono, Email, CuilCuit, FechaDeAlta, Estado_Civil, Nacionalidad, Provincia, Codigo_Postal, Barrio, Telefono_Alternativo, RedSocial_IG, ProfesionOcupacion, Lugar_Trabajo, Nivel_Estudios, Estado, MetodoPago_Preferido, ObservacionesNotas FROM agenda WHERE nombre = @Nombre";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Nombre", nombre);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string dniDb = reader["Dni"].ToString();
                        string apellidoDb = reader["Apellido"].ToString();
                        string nombreDb = reader["Nombre"].ToString();
                        string calleDb = reader["Calle"].ToString();
                        string deptoDb = reader["Depto"].ToString();
                        int pisoDb = Convert.ToInt32(reader["Piso"]);
                        string ciudadDb = reader["Ciudad"].ToString();
                        int telefonoDb = Convert.ToInt32(reader["Telefono"]);
                        string emailDb = reader["Email"].ToString();

                        string CuilCuitDb = reader["CuilCuit"].ToString();
                        string FechaDeAltaDb = reader["FechaDeAlta"].ToString();
                        string Estado_CivilDb = reader["Estado_Civil"].ToString();
                        string NacionalidadDb = reader["Nacionalidad"].ToString();
                        string ProvinciaDb = reader["Provincia"].ToString();
                        int Codigo_PostalDb = Convert.ToInt32(reader["Codigo_Postal"]);
                        string BarrioDb = reader["Barrio"].ToString();
                        int Telefono_AlternativoDb = Convert.ToInt32(reader["Telefono_Alternativo"]);
                        string RedSocial_IGDb = reader["RedSocial_IG"].ToString();
                        string ProfesionOcupacionDb = reader["ProfesionOcupacion"].ToString();
                        string Lugar_TrabajoDb = reader["Lugar_Trabajo"].ToString();
                        string Nivel_EstudiosDb = reader["Nivel_Estudios"].ToString();
                        string EstadoDb = reader["Estado"].ToString();
                        string MetodoPago_PreferidoDb = reader["MetodoPago_Preferido"].ToString();
                        string ObservacionesNotasDb = reader["ObservacionesNotas"].ToString();

                        return new ObjetoAgenda(dniDb, apellidoDb, nombreDb, calleDb, deptoDb, pisoDb, ciudadDb, telefonoDb, emailDb, CuilCuitDb, FechaDeAltaDb, Estado_CivilDb, NacionalidadDb, ProvinciaDb, Codigo_PostalDb, BarrioDb, Telefono_AlternativoDb, RedSocial_IGDb, ProfesionOcupacionDb, Lugar_TrabajoDb, Nivel_EstudiosDb, EstadoDb, MetodoPago_PreferidoDb, ObservacionesNotasDb);
                    }
                }
            }

            return null;
        }

        public ObjetoAgenda? BuscarPorCalle(string calle)
        {
            string query = "SELECT Dni, Apellido, Nombre, Calle, Depto, Piso, Ciudad, Telefono, Email, CuilCuit, FechaDeAlta, Estado_Civil, Nacionalidad, Provincia, Codigo_Postal, Barrio, Telefono_Alternativo, RedSocial_IG, ProfesionOcupacion, Lugar_Trabajo, Nivel_Estudios, Estado, MetodoPago_Preferido, ObservacionesNotas FROM agenda WHERE calle = @Calle";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Calle", calle);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string dniDb = reader["Dni"].ToString();
                        string apellidoDb = reader["Apellido"].ToString();
                        string nombreDb = reader["Nombre"].ToString();
                        string calleDb = reader["Calle"].ToString();
                        string deptoDb = reader["Depto"].ToString();
                        int pisoDb = Convert.ToInt32(reader["Piso"]);
                        string ciudadDb = reader["Ciudad"].ToString();
                        int telefonoDb = Convert.ToInt32(reader["Telefono"]);
                        string emailDb = reader["Email"].ToString();

                        string CuilCuitDb = reader["CuilCuit"].ToString();
                        string FechaDeAltaDb = reader["FechaDeAlta"].ToString();
                        string Estado_CivilDb = reader["Estado_Civil"].ToString();
                        string NacionalidadDb = reader["Nacionalidad"].ToString();
                        string ProvinciaDb = reader["Provincia"].ToString();
                        int Codigo_PostalDb = Convert.ToInt32(reader["Codigo_Postal"]);
                        string BarrioDb = reader["Barrio"].ToString();
                        int Telefono_AlternativoDb = Convert.ToInt32(reader["Telefono_Alternativo"]);
                        string RedSocial_IGDb = reader["RedSocial_IG"].ToString();
                        string ProfesionOcupacionDb = reader["ProfesionOcupacion"].ToString();
                        string Lugar_TrabajoDb = reader["Lugar_Trabajo"].ToString();
                        string Nivel_EstudiosDb = reader["Nivel_Estudios"].ToString();
                        string EstadoDb = reader["Estado"].ToString();
                        string MetodoPago_PreferidoDb = reader["MetodoPago_Preferido"].ToString();
                        string ObservacionesNotasDb = reader["ObservacionesNotas"].ToString();

                        return new ObjetoAgenda(dniDb, apellidoDb, nombreDb, calleDb, deptoDb, pisoDb, ciudadDb, telefonoDb, emailDb, CuilCuitDb, FechaDeAltaDb, Estado_CivilDb, NacionalidadDb, ProvinciaDb, Codigo_PostalDb, BarrioDb, Telefono_AlternativoDb, RedSocial_IGDb, ProfesionOcupacionDb, Lugar_TrabajoDb, Nivel_EstudiosDb, EstadoDb, MetodoPago_PreferidoDb, ObservacionesNotasDb);
                    }
                }
            }

            return null;
        }

        public bool Agregar(ObjetoAgenda agenda)
        {
            string query = "INSERT INTO agenda(Dni, Apellido, Nombre, Calle, Depto, Piso, Ciudad, Telefono, Email, CuilCuit, FechaDeAlta, Estado_Civil, Nacionalidad, Provincia, Codigo_Postal, Barrio, Telefono_Alternativo, RedSocial_IG, ProfesionOcupacion, Lugar_Trabajo, Nivel_Estudios, Estado, MetodoPago_Preferido, ObservacionesNotas) VALUES (@Dni, @Apellido, @Nombre, @Calle, @Depto, @Piso, @Ciudad, @Telefono, @Email, @CuilCuit, @FechaDeAlta, @Estado_Civil, @Nacionalidad, @Provincia, @Codigo_Postal, @Barrio, @Telefono_Alternativo, @RedSocial_IG, @ProfesionOcupacion, @Lugar_Trabajo, @Nivel_Estudios, @Estado, @MetodoPago_Preferido, @ObservacionesNotas)";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Dni", agenda.Dni);
                comando.Parameters.AddWithValue("@Apellido", agenda.Apellido);
                comando.Parameters.AddWithValue("@Nombre", agenda.Nombre);
                comando.Parameters.AddWithValue("@Calle", agenda.Calle);
                comando.Parameters.AddWithValue("@Depto", agenda.Depto);
                comando.Parameters.AddWithValue("@Piso", agenda.Piso);
                comando.Parameters.AddWithValue("@Ciudad", agenda.Ciudad);
                comando.Parameters.AddWithValue("@Telefono", agenda.Telefono);
                comando.Parameters.AddWithValue("@Email", agenda.Email);

                comando.Parameters.AddWithValue("@CuilCuit", agenda.CuilCuit);
                comando.Parameters.AddWithValue("@FechaDeAlta", agenda.FechaDeAlta);
                comando.Parameters.AddWithValue("@Estado_Civil", agenda.Estado_Civil);
                comando.Parameters.AddWithValue("@Nacionalidad", agenda.Nacionalidad);
                comando.Parameters.AddWithValue("@Provincia", agenda.Provincia);
                comando.Parameters.AddWithValue("@Codigo_Postal", agenda.Codigo_Postal);
                comando.Parameters.AddWithValue("@Barrio", agenda.Barrio);
                comando.Parameters.AddWithValue("@Telefono_Alternativo", agenda.Telefono_Alternativo);
                comando.Parameters.AddWithValue("@RedSocial_IG", agenda.RedSocial_IG);
                comando.Parameters.AddWithValue("@ProfesionOcupacion", agenda.ProfesionOcupacion);
                comando.Parameters.AddWithValue("@Lugar_Trabajo", agenda.Lugar_Trabajo);
                comando.Parameters.AddWithValue("@Nivel_Estudios", agenda.Nivel_Estudios);
                comando.Parameters.AddWithValue("@Estado", agenda.Estado);
                comando.Parameters.AddWithValue("@MetodoPago_Preferido", agenda.MetodoPago_Preferido);
                comando.Parameters.AddWithValue("@ObservacionesNotas", agenda.ObservacionesNotas);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0;
            }
        }

        public bool Modificar(string Dni, string nuevoApellido, string nuevoNombre, string nuevoCalle, string nuevoDepto, int nuevoPiso, string nuevoCiudad, int nuevoTelefono, string nuevoEmail, string nuevoCuilCuit, string nuevoFechaDeAlta, string nuevoEstado_Civil, string nuevoNacionalidad, string nuevoProvincia, int nuevoCodigo_Postal, string nuevoBarrio, int nuevoTelefono_Alternativo, string nuevoRedSocial_IG, string nuevoProfesionOcupacion, string nuevoLugar_Trabajo, string nuevoNivel_Estudios, string nuevoEstado, string nuevoMetodoPago_Preferido, string nuevoObservacionesNotas
)
        {
            string query = "UPDATE agenda SET Apellido = @Apellido, Nombre = @Nombre, Calle = @Calle, Depto = @Depto, Piso = @Piso, Ciudad = @Ciudad, Telefono = @Telefono, Email = @Email, CuilCuit = @CuilCuit, FechaDeAlta = @FechaDeAlta, Estado_Civil = @Estado_Civil, Nacionalidad = @Nacionalidad, Provincia = @Provincia, Codigo_Postal = @Codigo_Postal, Barrio = @Barrio, Telefono_Alternativo = @Telefono_Alternativo, RedSocial_IG = @RedSocial_IG, ProfesionOcupacion = @ProfesionOcupacion, Lugar_Trabajo = @Lugar_Trabajo, Nivel_Estudios = @Nivel_Estudios, Estado = @Estado,  MetodoPago_Preferido = @MetodoPago_Preferido, ObservacionesNotas = @ObservacionesNotas\r\n WHERE Dni = @Dni";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Dni", Dni);
                comando.Parameters.AddWithValue("@Apellido", nuevoApellido);
                comando.Parameters.AddWithValue("@Nombre", nuevoNombre);
                comando.Parameters.AddWithValue("@Calle", nuevoCalle);
                comando.Parameters.AddWithValue("@Depto", nuevoDepto);
                comando.Parameters.AddWithValue("@Piso", nuevoPiso);
                comando.Parameters.AddWithValue("@Ciudad", nuevoCiudad);
                comando.Parameters.AddWithValue("@Telefono", nuevoTelefono);
                comando.Parameters.AddWithValue("@Email", nuevoEmail);

                comando.Parameters.AddWithValue("@CuilCuit", nuevoCuilCuit);
                comando.Parameters.AddWithValue("@FechaDeAlta", nuevoFechaDeAlta);
                comando.Parameters.AddWithValue("@Estado_Civil", nuevoEstado_Civil);
                comando.Parameters.AddWithValue("@Nacionalidad", nuevoNacionalidad);
                comando.Parameters.AddWithValue("@Provincia", nuevoProvincia);
                comando.Parameters.AddWithValue("@Codigo_Postal", nuevoCodigo_Postal);
                comando.Parameters.AddWithValue("@Barrio", nuevoBarrio);
                comando.Parameters.AddWithValue("@Telefono_Alternativo", nuevoTelefono_Alternativo);
                comando.Parameters.AddWithValue("@RedSocial_IG", nuevoRedSocial_IG);
                comando.Parameters.AddWithValue("@ProfesionOcupacion", nuevoProfesionOcupacion);
                comando.Parameters.AddWithValue("@Lugar_Trabajo", nuevoLugar_Trabajo);
                comando.Parameters.AddWithValue("@Nivel_Estudios", nuevoNivel_Estudios);
                comando.Parameters.AddWithValue("@Estado", nuevoEstado);
                comando.Parameters.AddWithValue("@MetodoPago_Preferido", nuevoMetodoPago_Preferido);
                comando.Parameters.AddWithValue("@ObservacionesNotas", nuevoObservacionesNotas);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0;
            }
        }

        public bool Eliminar(string dni)
        {
            string query = "DELETE FROM agenda WHERE dni = @Dni";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Dni", dni);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0;
            }
        }
    }
}
