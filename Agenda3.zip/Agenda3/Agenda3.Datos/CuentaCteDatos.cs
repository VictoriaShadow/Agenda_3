﻿using Agenda3.Entidades;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace Agenda3.Datos
{
    public class CuentaCteDatos
    {
        private string _conexionString = "Server=localhost;Database=agenda;Uid=root;Pwd=;";

        public ObjetoCuentaCte? BuscarPorPersona(string persona)
        {
            string query = "SELECT Id_CuentaCte, Persona, FechaApertura, LimiteCredito, EstadoCredito FROM cuentacte WHERE Persona = @Persona";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);

                comando.Parameters.AddWithValue("@Persona", persona);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int id_CuentaCteDb = Convert.ToInt32(reader["Id_CuentaCte"]);
                        string personaDb = reader["Persona"].ToString();
                        string fechaAperturaDb = reader["FechaApertura"].ToString();
                        decimal limiteCreditoDb = Convert.ToDecimal(reader["LimiteCredito"]);
                        string estadoCreditoDb = reader["EstadoCredito"].ToString();

                        return new ObjetoCuentaCte(id_CuentaCteDb, personaDb, fechaAperturaDb, limiteCreditoDb, estadoCreditoDb);
                    }
                }
            }

            return null;
        }

        public bool AgregarC(ObjetoCuentaCte cuenta)
        {
            string query = "INSERT INTO cuentacte(Persona, FechaApertura, LimiteCredito, EstadoCredito) VALUES (@Persona, @FechaApertura, @LimiteCredito, @EstadoCredito)";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);

                comando.Parameters.AddWithValue("@Persona", cuenta.Persona);
                comando.Parameters.AddWithValue("@FechaApertura", cuenta.FechaApertura);
                comando.Parameters.AddWithValue("@LimiteCredito", cuenta.LimiteCredito);
                comando.Parameters.AddWithValue("@EstadoCredito", cuenta.EstadoCredito);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();

                return filasAfectadas > 0;
            }
        }

        public bool ModificarC(ObjetoCuentaCte cuenta)
        {
            string query = "UPDATE cuentacte SET Persona = @Persona, FechaApertura = @FechaApertura, LimiteCredito = @LimiteCredito, EstadoCredito = @EstadoCredito WHERE Id_CuentaCte = @Id_CuentaCte";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);

                comando.Parameters.AddWithValue("@Id_CuentaCte", cuenta.Id_CuentaCte);
                comando.Parameters.AddWithValue("@Persona", cuenta.Persona);
                comando.Parameters.AddWithValue("@FechaApertura", cuenta.FechaApertura);
                comando.Parameters.AddWithValue("@LimiteCredito", cuenta.LimiteCredito);
                comando.Parameters.AddWithValue("@EstadoCredito", cuenta.EstadoCredito);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();

                return filasAfectadas > 0;
            }
        }

        public bool EliminarC(int id_CuentaCte)
        {
            string query = "DELETE FROM cuentacte WHERE Id_CuentaCte = @Id_CuentaCte";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);

                comando.Parameters.AddWithValue("@Id_CuentaCte", id_CuentaCte);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();

                return filasAfectadas > 0;
            }
        }
    }
}
