﻿namespace Agenda3.Entidades
{
    public class ObjetoAgenda
    {
        public string Dni { get; set; }
        public string Apellido { get; set; }
        public string Nombre { get; set; }
        public string Calle { get; set; }
        public string Depto { get; set; }
        public int Piso { get; set; }
        public string Ciudad { get; set; }
        public int Telefono { get; set; }
        public string Email { get; set; }
        public string CuilCuit { get; set; }
        public string FechaDeAlta { get; set; }
        public string Estado_Civil { get; set; }
        public string Nacionalidad { get; set; }
        public string Provincia { get; set; }
        public int Codigo_Postal { get; set; }
        public string Barrio { get; set; }
        public int Telefono_Alternativo { get; set; }
        public string RedSocial_IG { get; set; }
        public string ProfesionOcupacion { get; set; }
        public string Lugar_Trabajo { get; set; }
        public string Nivel_Estudios { get; set; }
        public string Estado { get; set; }
        public string MetodoPago_Preferido { get; set; }
        public string ObservacionesNotas { get; set; }

        public ObjetoAgenda(string dni, string apellido, string nombre, string calle, string depto, int piso, string ciudad, int telefono, string email, string cuilCuit, string fechaDeAlta, string estado_Civil, string nacionalidad, string provincia, int codigo_Postal, string barrio, int telefono_Alternativo, string redSocial_IG, string profesionOcupacion, string lugar_Trabajo, string nivel_Estudios,string estado,string metodoPago_Preferido,string observacionesNotas)
        {
            Dni = dni;
            Apellido = apellido;
            Nombre = nombre;
            Calle = calle;
            Depto = depto;
            Piso = piso;
            Ciudad = ciudad;
            Telefono = telefono;
            Email = email;
            CuilCuit = cuilCuit;
            FechaDeAlta = fechaDeAlta;
            Estado_Civil = estado_Civil;
            Nacionalidad = nacionalidad;
            Provincia = provincia;
            Codigo_Postal = codigo_Postal;
            Barrio = barrio;
            Telefono_Alternativo = telefono_Alternativo;
            RedSocial_IG = redSocial_IG;
            ProfesionOcupacion = profesionOcupacion;
            Lugar_Trabajo = lugar_Trabajo;
            Nivel_Estudios = nivel_Estudios;
            Estado = estado;
            MetodoPago_Preferido = metodoPago_Preferido;
            ObservacionesNotas = observacionesNotas;
        }
        public ObjetoAgenda()
        {
        }
    }
}
