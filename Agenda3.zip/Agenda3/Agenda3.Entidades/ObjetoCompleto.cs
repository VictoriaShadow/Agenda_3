﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agenda3.Entidades
{
    public class ObjetoCompleto
    {
        public ObjetoAgenda Agenda {  get; set; }
        public ObjetoCuentaCte Cuenta {  get; set; }

    public ObjetoCompleto(ObjetoAgenda agenda, ObjetoCuentaCte cuenta)
        {
            Agenda = agenda;
            Cuenta = cuenta;
        }

    public ObjetoCompleto() { }
    }
}
