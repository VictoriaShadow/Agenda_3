﻿namespace Agenda3.Entidades
{
    public class ObjetoCuentaCte
    {
        public int Id_CuentaCte { get; set;  }
        public string Persona { get; set; }
        public string FechaApertura { get; set; }
        public decimal LimiteCredito { get; set; }
        public string EstadoCredito { get; set; }
    public ObjetoCuentaCte(int id_CuentaCte, string persona, string fechaApertura, decimal limiteCredito, string estadoCredito)
        {
            Id_CuentaCte = id_CuentaCte;
            Persona = persona;
            FechaApertura = fechaApertura;
            LimiteCredito = limiteCredito;
            EstadoCredito = estadoCredito;
        }

    public ObjetoCuentaCte()
        {
        }
    }
}
