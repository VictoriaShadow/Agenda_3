﻿using Agenda3.Datos;
using Agenda3.Entidades;
using System.Net;

namespace Agenda3.Negocio
{

    public class AgendaNegocio
    {

        private AgendaDatos _datos = new AgendaDatos();
        private CuentaCteDatos _datosCuenta = new CuentaCteDatos();

        public ObjetoCompleto ObtenerPorDni(string dni)
        {
            if (string.IsNullOrEmpty(dni)) return null;

            var resultado = _datos.BuscarPorDni(dni);

            if (resultado == null) return null;

            ObjetoAgenda agendaD = new ObjetoAgenda

            {
                Dni = resultado.Dni,
                Apellido = resultado.Apellido,
                Nombre = resultado.Nombre,
                Calle = resultado.Calle,
                Depto = resultado.Depto,
                Piso = resultado.Piso,
                Ciudad = resultado.Ciudad,
                Telefono = resultado.Telefono,
                Email = resultado.Email,

                CuilCuit = resultado.CuilCuit,
                FechaDeAlta = resultado.FechaDeAlta,
                Estado_Civil = resultado.Estado_Civil,
                Nacionalidad = resultado.Nacionalidad,
                Provincia = resultado.Provincia,
                Codigo_Postal = resultado.Codigo_Postal,
                Barrio = resultado.Barrio,
                Telefono_Alternativo = resultado.Telefono_Alternativo,
                RedSocial_IG = resultado.RedSocial_IG,
                ProfesionOcupacion = resultado.ProfesionOcupacion,
                Lugar_Trabajo = resultado.Lugar_Trabajo,
                Nivel_Estudios = resultado.Nivel_Estudios,
                Estado = resultado.Estado,
                MetodoPago_Preferido = resultado.MetodoPago_Preferido,
                ObservacionesNotas = resultado.ObservacionesNotas
            };
            ObjetoCuentaCte cuentaD = _datosCuenta.BuscarPorPersona(dni);

            return new ObjetoCompleto(agendaD, cuentaD);
        }

        public ObjetoCompleto ObtenerPorApellido(string apellido)
        {
            if (string.IsNullOrEmpty(apellido)) return null;

            var resultado = _datos.BuscarPorApellido(apellido);

            if (resultado == null) return null;
            ObjetoAgenda agendaAp = new ObjetoAgenda
            {
                Dni = resultado.Dni,
                Apellido = resultado.Apellido,
                Nombre = resultado.Nombre,
                Calle = resultado.Calle,
                Depto = resultado.Depto,
                Piso = resultado.Piso,
                Ciudad = resultado.Ciudad,
                Telefono = resultado.Telefono,
                Email = resultado.Email,

                CuilCuit = resultado.CuilCuit,
                FechaDeAlta = resultado.FechaDeAlta,
                Estado_Civil = resultado.Estado_Civil,
                Nacionalidad = resultado.Nacionalidad,
                Provincia = resultado.Provincia,
                Codigo_Postal = resultado.Codigo_Postal,
                Barrio = resultado.Barrio,
                Telefono_Alternativo = resultado.Telefono_Alternativo,
                RedSocial_IG = resultado.RedSocial_IG,
                ProfesionOcupacion = resultado.ProfesionOcupacion,
                Lugar_Trabajo = resultado.Lugar_Trabajo,
                Nivel_Estudios = resultado.Nivel_Estudios,
                Estado = resultado.Estado,
                MetodoPago_Preferido = resultado.MetodoPago_Preferido,
                ObservacionesNotas = resultado.ObservacionesNotas
            };
            ObjetoCuentaCte cuentaAp = _datosCuenta.BuscarPorPersona(apellido);

            return new ObjetoCompleto(agendaAp, cuentaAp);
        }

        public ObjetoCompleto ObtenerPorNombre(string nombre)
        {
            if (string.IsNullOrEmpty(nombre)) return null;

            var resultado = _datos.BuscarPorNombre(nombre);

            if (resultado == null) return null;
            ObjetoAgenda agendaN = new ObjetoAgenda
            {
                Dni = resultado.Dni,
                Apellido = resultado.Apellido,
                Nombre = resultado.Nombre,
                Calle = resultado.Calle,
                Depto = resultado.Depto,
                Piso = resultado.Piso,
                Ciudad = resultado.Ciudad,
                Telefono = resultado.Telefono,
                Email = resultado.Email,

                CuilCuit = resultado.CuilCuit,
                FechaDeAlta = resultado.FechaDeAlta,
                Estado_Civil = resultado.Estado_Civil,
                Nacionalidad = resultado.Nacionalidad,
                Provincia = resultado.Provincia,
                Codigo_Postal = resultado.Codigo_Postal,
                Barrio = resultado.Barrio,
                Telefono_Alternativo = resultado.Telefono_Alternativo,
                RedSocial_IG = resultado.RedSocial_IG,
                ProfesionOcupacion = resultado.ProfesionOcupacion,
                Lugar_Trabajo = resultado.Lugar_Trabajo,
                Nivel_Estudios = resultado.Nivel_Estudios,
                Estado = resultado.Estado,
                MetodoPago_Preferido = resultado.MetodoPago_Preferido,
                ObservacionesNotas = resultado.ObservacionesNotas
            };

            ObjetoCuentaCte cuentaN = _datosCuenta.BuscarPorPersona(nombre);

            return new ObjetoCompleto(agendaN, cuentaN);
        }

        public ObjetoCompleto ObtenerPorCalle(string calle)
        {
            if (string.IsNullOrEmpty(calle)) return null;

            var resultado = _datos.BuscarPorCalle(calle);

            if (resultado == null) return null;
            ObjetoAgenda agendaC = new ObjetoAgenda
            {
                Dni = resultado.Dni,
                Apellido = resultado.Apellido,
                Nombre = resultado.Nombre,
                Calle = resultado.Calle,
                Depto = resultado.Depto,
                Piso = resultado.Piso,
                Ciudad = resultado.Ciudad,
                Telefono = resultado.Telefono,
                Email = resultado.Email,

                CuilCuit = resultado.CuilCuit,
                FechaDeAlta = resultado.FechaDeAlta,
                Estado_Civil = resultado.Estado_Civil,
                Nacionalidad = resultado.Nacionalidad,
                Provincia = resultado.Provincia,
                Codigo_Postal = resultado.Codigo_Postal,
                Barrio = resultado.Barrio,
                Telefono_Alternativo = resultado.Telefono_Alternativo,
                RedSocial_IG = resultado.RedSocial_IG,
                ProfesionOcupacion = resultado.ProfesionOcupacion,
                Lugar_Trabajo = resultado.Lugar_Trabajo,
                Nivel_Estudios = resultado.Nivel_Estudios,
                Estado = resultado.Estado,
                MetodoPago_Preferido = resultado.MetodoPago_Preferido,
                ObservacionesNotas = resultado.ObservacionesNotas
            };

            ObjetoCuentaCte cuentaC = _datosCuenta.BuscarPorPersona(calle);

            return new ObjetoCompleto(agendaC, cuentaC);
        }





        public bool AgregarAgenda(ObjetoCompleto completo)
        {
            if (completo == null)
                return false;

            if (completo.Agenda == null || completo.Cuenta == null)
                return false;

            if (string.IsNullOrWhiteSpace(completo.Agenda.Dni) ||
                string.IsNullOrWhiteSpace(completo.Agenda.Nombre))
                return false;

            if (_datos.BuscarPorDni(completo.Agenda.Dni) != null)
                return false;

            bool agendaAgregada = _datos.Agregar(completo.Agenda);

            if (!agendaAgregada)
                return false;

            completo.Cuenta.Persona = completo.Agenda.Dni;

            bool cuentaAgregada = _datosCuenta.AgregarC(completo.Cuenta);

            return cuentaAgregada;
        }


        public bool ModificarAgenda(ObjetoCompleto completo)
        {
            if (completo == null)
                return false;

            if (completo.Agenda == null || completo.Cuenta == null)
                return false;

            if (string.IsNullOrWhiteSpace(completo.Agenda.Dni) ||
                string.IsNullOrWhiteSpace(completo.Agenda.Nombre))
                return false;

            bool agendaModificada = _datos.Modificar(
                completo.Agenda.Dni,
                completo.Agenda.Apellido,
                completo.Agenda.Nombre,
                completo.Agenda.Calle,
                completo.Agenda.Depto,
                completo.Agenda.Piso,
                completo.Agenda.Ciudad,
                completo.Agenda.Telefono,
                completo.Agenda.Email,
                completo.Agenda.CuilCuit,
                completo.Agenda.FechaDeAlta,
                completo.Agenda.Estado_Civil,
                completo.Agenda.Nacionalidad,
                completo.Agenda.Provincia,
                completo.Agenda.Codigo_Postal,
                completo.Agenda.Barrio,
                completo.Agenda.Telefono_Alternativo,
                completo.Agenda.RedSocial_IG,
                completo.Agenda.ProfesionOcupacion,
                completo.Agenda.Lugar_Trabajo,
                completo.Agenda.Nivel_Estudios,
                completo.Agenda.Estado,
                completo.Agenda.MetodoPago_Preferido,
                completo.Agenda.ObservacionesNotas
            );

            if (!agendaModificada)
                return false;

            var cuentaExistente = _datosCuenta.BuscarPorPersona(completo.Agenda.Dni);

            if (cuentaExistente == null)
                return false;

            completo.Cuenta.Id_CuentaCte = cuentaExistente.Id_CuentaCte;
            completo.Cuenta.Persona = completo.Agenda.Dni;

            bool cuentaModificada = _datosCuenta.ModificarC(completo.Cuenta);

            return cuentaModificada;
        }


        public bool EliminarAgenda(string dni)
        {
            if (string.IsNullOrWhiteSpace(dni))
                return false;

            var cuentaExistente = _datosCuenta.BuscarPorPersona(dni);

            if (cuentaExistente != null)
            {
                bool cuentaEliminada =
                    _datosCuenta.EliminarC(cuentaExistente.Id_CuentaCte);

                if (!cuentaEliminada)
                    return false;
            }

            return _datos.Eliminar(dni);
        }

    }
}
