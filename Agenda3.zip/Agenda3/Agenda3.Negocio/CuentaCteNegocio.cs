﻿using Agenda3.Entidades;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;
using Agenda3.Datos;

namespace Agenda3.Negocio
{
    public class CuentaCteNegocio
    {
        private CuentaCteDatos _datos = new CuentaCteDatos();

        public ObjetoCuentaCte ObtenerPorPersona(string persona)
        {
            if (string.IsNullOrWhiteSpace(persona))
                return null;

            return _datos.BuscarPorPersona(persona);
        }

        public bool AgregarCuenta(ObjetoCuentaCte cuenta)
        {
            if (cuenta == null)
                return false;

            if (string.IsNullOrWhiteSpace(cuenta.Persona))
                return false;

            if (string.IsNullOrWhiteSpace(cuenta.FechaApertura))
                return false;

            if (cuenta.LimiteCredito < 0)
                return false;

            if (cuenta.EstadoCredito != "Activo" &&
                cuenta.EstadoCredito != "Suspendido")
                return false;

            if (_datos.BuscarPorPersona(cuenta.Persona) != null)
                return false;

            return _datos.AgregarC(cuenta);
        }

        public bool ModificarCuenta(ObjetoCuentaCte cuenta)
        {
            if (cuenta == null)
                return false;

            if (cuenta.Id_CuentaCte <= 0)
                return false;

            if (string.IsNullOrWhiteSpace(cuenta.Persona))
                return false;

            if (string.IsNullOrWhiteSpace(cuenta.FechaApertura))
                return false;

            if (cuenta.LimiteCredito < 0)
                return false;

            if (cuenta.EstadoCredito != "Activo" &&
                cuenta.EstadoCredito != "Suspendido")
                return false;

            return _datos.ModificarC(cuenta);
        }

        public bool EliminarCuenta(int id_CuentaCte)
        {
            if (id_CuentaCte <= 0)
                return false;

            return _datos.EliminarC(id_CuentaCte);
        }
    }
}
