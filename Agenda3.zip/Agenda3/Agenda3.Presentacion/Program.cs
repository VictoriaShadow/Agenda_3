﻿using Agenda3.Entidades;
using Agenda3.Negocio;
using System;
using static System.Runtime.InteropServices.JavaScript.JSType;

public class Program
{
    public static void Main()
    {

        AgendaNegocio negocio = new AgendaNegocio();
        int opcion;

        do
        {
            Console.Clear();
            Console.WriteLine("===== MENÚ =====");
            Console.WriteLine("1. Agregar agenda");
            Console.WriteLine("2. Modificar agenda");
            Console.WriteLine("3. Eliminar agenda");
            Console.WriteLine("4. Buscar agenda por DNI");
            Console.WriteLine("5. Buscar agenda por Apellido");
            Console.WriteLine("6. Buscar agenda por Nombre");
            Console.WriteLine("7. Buscar agenda por Calle");
            Console.WriteLine("8. Salir");
            Console.Write("Seleccione una opción: ");

            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.WriteLine("===== Agregar agenda =====");

                    Console.Write("Ingrese DNI de nueva agenda: ");
                    string dniA = Console.ReadLine();
                    Console.Write("Ingrese apellido de nueva agenda: ");
                    string apellidoA = Console.ReadLine();
                    Console.Write("Ingrese nombre de nueva agenda: ");
                    string nombreA = Console.ReadLine();
                    Console.Write("Ingrese calle de nueva agenda: ");
                    string calleA = Console.ReadLine();
                    Console.Write("Ingrese depto de nueva agenda: ");
                    string deptoA = Console.ReadLine();
                    Console.Write("Ingrese piso de nueva agenda: ");
                    int pisoA = int.Parse(Console.ReadLine());
                    Console.Write("Ingrese ciudad de nueva agenda: ");
                    string ciudadA = Console.ReadLine();
                    Console.Write("Ingrese nuevo teléfono: ");
                    int telefonoA = int.Parse(Console.ReadLine());
                    Console.Write("Ingrese email de nueva agenda: ");
                    string emailA = Console.ReadLine();


                    Console.Write("Ingrese nuevo Cuil/Cuit: ");
                    string cuilCuitA = Console.ReadLine();

                    Console.Write("Ingrese nueva fecha: ");
                    string fechaDeAltaA = Console.ReadLine();

                    Console.Write("Ingrese buevo estado civil: ");
                    string estado_CivilA = Console.ReadLine();

                    Console.Write("Ingrese nacionalidad: ");
                    string nacionalidadA = Console.ReadLine();

                    Console.Write("Ingrese provincia: ");
                    string provinciaA = Console.ReadLine();

                    Console.Write("Ingrese nuevo código postal: ");
                    int codigo_PostalA = int.Parse(Console.ReadLine());

                    Console.Write("Ingrese nuevo barrio: ");
                    string barrioA = Console.ReadLine();

                    Console.Write("Ingrese nuevo teléfono alternativo:");
                    int telefono_AlternativoA = int.Parse(Console.ReadLine());

                    Console.Write("Ingrese nueva red social(Instagram): ");
                    string redSocial_IGA = Console.ReadLine();

                    Console.Write("Ingrese nuevo ocupación: ");
                    string profesionOcupacionA = Console.ReadLine();

                    Console.Write("Ingrese nuevo lugar de trabajo: ");
                    string lugar_TrabajoA = Console.ReadLine();

                    Console.Write("Ingrese nivel de estudios: ");
                    string nivel_EstudiosA = Console.ReadLine();

                    Console.Write("Ingrese nuevo estado: ");
                    string estadoA = Console.ReadLine();

                    Console.Write("Ingrese método de pago preferido: ");
                    string metodoPago_PreferidoA = Console.ReadLine();

                    Console.Write("Ingrese nuevas observaciones y/o notas: ");
                    string observacionesNotasA = Console.ReadLine();

                    Console.Write("Ingrese nueva fecha: ");
                    string fechaAperturaA = Console.ReadLine();

                    Console.Write("Ingrese nuevo limite de credito: ");
                    decimal limiteCreditoA = Convert.ToDecimal(Console.ReadLine());

                    Console.Write("Ingrese nuevo estado de credito: ");
                    string estadoCreditoA = Console.ReadLine();



                    ObjetoAgenda agendaNueva = new ObjetoAgenda();
                    agendaNueva.Dni = dniA;
                    agendaNueva.Apellido = apellidoA;
                    agendaNueva.Nombre = nombreA;
                    agendaNueva.Calle = calleA;
                    agendaNueva.Depto = deptoA;
                    agendaNueva.Piso = pisoA;
                    agendaNueva.Ciudad = ciudadA;
                    agendaNueva.Telefono = telefonoA;
                    agendaNueva.Email = emailA;

                    agendaNueva.CuilCuit = cuilCuitA;
                    agendaNueva.FechaDeAlta = fechaDeAltaA;
                    agendaNueva.Estado_Civil = estado_CivilA;
                    agendaNueva.Nacionalidad = nacionalidadA;
                    agendaNueva.Provincia = provinciaA;
                    agendaNueva.Codigo_Postal = codigo_PostalA;
                    agendaNueva.Barrio = barrioA;
                    agendaNueva.Telefono_Alternativo = telefono_AlternativoA;
                    agendaNueva.RedSocial_IG = redSocial_IGA;
                    agendaNueva.ProfesionOcupacion = profesionOcupacionA;
                    agendaNueva.Lugar_Trabajo = lugar_TrabajoA;
                    agendaNueva.Nivel_Estudios = nivel_EstudiosA;
                    agendaNueva.Estado = estadoA;
                    agendaNueva.MetodoPago_Preferido = metodoPago_PreferidoA;
                    agendaNueva.ObservacionesNotas = observacionesNotasA;

                    ObjetoCuentaCte cuentaA = new ObjetoCuentaCte
                    {
                        Persona = agendaNueva.Dni,
                        FechaApertura = fechaAperturaA,
                        LimiteCredito = limiteCreditoA,
                        EstadoCredito = estadoCreditoA
                    };

                    ObjetoCompleto completoA = new ObjetoCompleto(agendaNueva, cuentaA);

                    bool agregado = negocio.AgregarAgenda(completoA);

                    if (agregado)
                    {
                        Console.WriteLine("Agenda agregada.");
                    }
                    else
                    {
                        Console.WriteLine("No se ha podido agregar.");
                    }
                    Console.WriteLine("Presiona cualquier tecla para continuar...");
                    ConsoleKeyInfo teclaA = Console.ReadKey();

                    break;

                case 2:
                    Console.WriteLine("===== Modificar agenda =====");
                    Console.Write("Ingrese el DNI: ");
                    string dniM = Console.ReadLine();

                    Console.Write("Ingrese nuevo apellido: ");
                    string apellidoM = Console.ReadLine();

                    Console.Write("Ingrese nuevo nombre: ");
                    string nombreM = Console.ReadLine();

                    Console.Write("Ingrese el calle: ");
                    string calleM = Console.ReadLine();

                    Console.Write("Ingrese nuevo depto: ");
                    string deptoM = Console.ReadLine();

                    Console.Write("Ingrese nuevo piso: ");
                    int pisoM = int.Parse(Console.ReadLine());

                    Console.Write("Ingrese el ciudad: ");
                    string ciudadM = Console.ReadLine();

                    Console.Write("Ingrese nuevo teléfono: ");
                    int telefonoM = int.Parse(Console.ReadLine());

                    Console.Write("Ingrese nuevo email: ");
                    string emailM = Console.ReadLine();


                    Console.Write("Ingrese nuevo Cuil/Cuit: ");
                    string cuilCuitM = Console.ReadLine();

                    Console.Write("Ingrese nueva fecha: ");
                    string fechaDeAltaM = Console.ReadLine();

                    Console.Write("Ingrese buevo estado civil: ");
                    string estado_CivilM = Console.ReadLine();

                    Console.Write("Ingrese nacionalidad: ");
                    string nacionalidadM = Console.ReadLine();

                    Console.Write("Ingrese provincia: ");
                    string provinciaM = Console.ReadLine();

                    Console.Write("Ingrese nuevo código postal: ");
                    int codigo_PostalM = int.Parse(Console.ReadLine());

                    Console.Write("Ingrese nuevo barrio: ");
                    string barrioM = Console.ReadLine();

                    Console.Write("Ingrese nuevo teléfono alternativo:");
                    int telefono_AlternativoM = int.Parse(Console.ReadLine());

                    Console.Write("Ingrese nueva red social(Instagram): ");
                    string redSocial_IGM = Console.ReadLine();

                    Console.Write("Ingrese nuevo ocupación: ");
                    string profesionOcupacionM = Console.ReadLine();

                    Console.Write("Ingrese nuevo lugar de trabajo: ");
                    string lugar_TrabajoM = Console.ReadLine();

                    Console.Write("Ingrese nivel de estudios: ");
                    string nivel_EstudiosM = Console.ReadLine();

                    Console.Write("Ingrese nuevo estado: ");
                    string estadoM = Console.ReadLine();

                    Console.Write("Ingrese método de pago preferido");
                    string metodoPago_PreferidoM = Console.ReadLine();

                    Console.Write("Ingrese nuevas observaciones y/o notas: ");
                    string observacionesNotasM = Console.ReadLine();

                    Console.Write("Ingrese nueva fecha: ");
                    string fechaAperturaM = Console.ReadLine();

                    Console.Write("Ingrese nuevo limite de credito: ");
                    decimal limiteCreditoM = Convert.ToDecimal(Console.ReadLine());

                    Console.Write("Ingrese nuevo estado de credito: ");
                    string estadoCreditoM = Console.ReadLine();


                    ObjetoAgenda agendaModificar = new ObjetoAgenda();
                    agendaModificar.Dni = dniM;
                    agendaModificar.Apellido = apellidoM;
                    agendaModificar.Nombre = nombreM;
                    agendaModificar.Calle = calleM;
                    agendaModificar.Depto = deptoM;
                    agendaModificar.Piso = pisoM;
                    agendaModificar.Ciudad = ciudadM;
                    agendaModificar.Telefono = telefonoM;
                    agendaModificar.Email = emailM;

                    agendaModificar.CuilCuit = cuilCuitM;
                    agendaModificar.FechaDeAlta = fechaDeAltaM;
                    agendaModificar.Estado_Civil = estado_CivilM;
                    agendaModificar.Nacionalidad = nacionalidadM;
                    agendaModificar.Provincia = provinciaM;
                    agendaModificar.Codigo_Postal = codigo_PostalM;
                    agendaModificar.Barrio = barrioM;
                    agendaModificar.Telefono_Alternativo = telefono_AlternativoM;
                    agendaModificar.RedSocial_IG = redSocial_IGM;
                    agendaModificar.ProfesionOcupacion = profesionOcupacionM;
                    agendaModificar.Lugar_Trabajo = lugar_TrabajoM;
                    agendaModificar.Nivel_Estudios = nivel_EstudiosM;
                    agendaModificar.Estado = estadoM;
                    agendaModificar.MetodoPago_Preferido = metodoPago_PreferidoM;
                    agendaModificar.ObservacionesNotas = observacionesNotasM;

                    ObjetoCuentaCte cuentaModificar = new ObjetoCuentaCte
                    {
                        Persona = agendaModificar.Dni,
                        FechaApertura = fechaAperturaM,
                        LimiteCredito = limiteCreditoM,
                        EstadoCredito = estadoCreditoM
                    };

                    ObjetoCompleto completoM = new ObjetoCompleto(agendaModificar, cuentaModificar);

                    bool modificado = negocio.ModificarAgenda(completoM);

                    if (modificado)
                    {
                        Console.WriteLine("Agenda modificado.");
                    }
                    else
                    {
                        Console.WriteLine("No se ha podido modificar.");
                    }
                    Console.WriteLine("Presiona cualquier tecla para continuar...");
                    ConsoleKeyInfo teclaM = Console.ReadKey();
                    break;

                case 3:

                    Console.WriteLine("===== Eliminar Agenda =====");
                    Console.Write("Ingrese el DNI: ");
                    string dniE = Console.ReadLine();

                    bool eliminado = negocio.EliminarAgenda(dniE);

                    if (eliminado)
                        Console.WriteLine("Agenda eliminada.");
                    else
                        Console.WriteLine("No se ha podido eliminar.");
                    Console.WriteLine("Presiona cualquier tecla para continuar...");
                    ConsoleKeyInfo teclaE = Console.ReadKey();
                    break;

                case 4:
                    Console.WriteLine("===== Buscar Agenda por DNI =====");
                    Console.Write("Ingrese DNI de la agenda: ");
                    string dniB = Console.ReadLine();

                    ObjetoCompleto completo4 = negocio.ObtenerPorDni(dniB);

                    if (completo4 != null)
                    {
                        Console.WriteLine($"Encontrado: {completo4.Agenda.Dni}, {completo4.Agenda.Apellido}, {completo4.Agenda.Nombre}, {completo4.Agenda.Calle}, {completo4.Agenda.Depto}, {completo4.Agenda.Piso}, {completo4.Agenda.Ciudad}, {completo4.Agenda.Telefono}, {completo4.Agenda.Email}, {completo4.Agenda.CuilCuit}, {completo4.Agenda.FechaDeAlta}, {completo4.Agenda.Estado_Civil}, {completo4.Agenda.Nacionalidad}, {completo4.Agenda.Provincia}, {completo4.Agenda.Codigo_Postal}, {completo4.Agenda.Barrio}, {completo4.Agenda.Telefono_Alternativo}, {completo4.Agenda.RedSocial_IG}, {completo4.Agenda.ProfesionOcupacion}, {completo4.Agenda.Lugar_Trabajo}, {completo4.Agenda.Nivel_Estudios}, {completo4.Agenda.Estado}, {completo4.Agenda.MetodoPago_Preferido}, {completo4.Agenda.ObservacionesNotas}");

                        if (completo4.Cuenta != null)
                        {
                            // datos de CuentaCte
                        }
                    }
                    else
                    {
                        Console.WriteLine("No existe.");
                    }

                    Console.WriteLine("Presiona cualquier tecla para continuar...");
                    ConsoleKeyInfo teclaD = Console.ReadKey();
                    break;

                case 5:
                    Console.WriteLine("===== Buscar Agenda por Apellido =====");
                    Console.Write("Ingrese apellido de la agenda: ");
                    string apellidoB = Console.ReadLine();

                    ObjetoCompleto completo5 = negocio.ObtenerPorApellido(apellidoB);

                    if (completo5 != null)

                        if (completo5 != null)
                        {
                            Console.WriteLine($"Encontrado: {completo5.Agenda.Dni}, {completo5.Agenda.Apellido}, {completo5.Agenda.Nombre}, {completo5.Agenda.Calle}, {completo5.Agenda.Depto}, {completo5.Agenda.Piso}, {completo5.Agenda.Ciudad}, {completo5.Agenda.Telefono}, {completo5.Agenda.Email}, {completo5.Agenda.CuilCuit}, {completo5.Agenda.FechaDeAlta}, {completo5.Agenda.Estado_Civil}, {completo5.Agenda.Nacionalidad}, {completo5.Agenda.Provincia}, {completo5.Agenda.Codigo_Postal}, {completo5.Agenda.Barrio}, {completo5.Agenda.Telefono_Alternativo}, {completo5.Agenda.RedSocial_IG}, {completo5.Agenda.ProfesionOcupacion}, {completo5.Agenda.Lugar_Trabajo}, {completo5.Agenda.Nivel_Estudios}, {completo5.Agenda.Estado}, {completo5.Agenda.MetodoPago_Preferido}, {completo5.Agenda.ObservacionesNotas}");

                            if (completo5.Cuenta != null)
                            {
                                // datos de CuentaCte
                            }
                        }
                        else
                        {
                            Console.WriteLine("No existe.");
                        }
                    
                    else
                        Console.WriteLine("No existe.");
                    Console.WriteLine("Presiona cualquier tecla para continuar...");
                    ConsoleKeyInfo teclaAp = Console.ReadKey();
                    break;

                case 6:
                    Console.WriteLine("===== Buscar Agenda por Nombre =====");
                    Console.Write("Ingrese nombre de la agenda: ");
                    string nombreB = Console.ReadLine();

                    ObjetoCompleto completo6 = negocio.ObtenerPorNombre(nombreB);

                    if (completo6 != null)
                    {
                        Console.WriteLine($"Encontrado: {completo6.Agenda.Dni}, {completo6.Agenda.Apellido}, {completo6.Agenda.Nombre}, {completo6.Agenda.Calle}, {completo6.Agenda.Depto}, {completo6.Agenda.Piso}, {completo6.Agenda.Ciudad}, {completo6.Agenda.Telefono}, {completo6.Agenda.Email}, {completo6.Agenda.CuilCuit}, {completo6.Agenda.FechaDeAlta}, {completo6.Agenda.Estado_Civil}, {completo6.Agenda.Nacionalidad}, {completo6.Agenda.Provincia}, {completo6.Agenda.Codigo_Postal}, {completo6.Agenda.Barrio}, {completo6.Agenda.Telefono_Alternativo}, {completo6.Agenda.RedSocial_IG}, {completo6.Agenda.ProfesionOcupacion}, {completo6.Agenda.Lugar_Trabajo}, {completo6.Agenda.Nivel_Estudios}, {completo6.Agenda.Estado}, {completo6.Agenda.MetodoPago_Preferido}, {completo6.Agenda.ObservacionesNotas}");

                        if (completo6.Cuenta != null)
                        {
                            // datos de CuentaCte
                        }
                    }
                    else
                    {
                        Console.WriteLine("No existe.");
                    }

                    Console.WriteLine("Presiona cualquier tecla para continuar...");
                    ConsoleKeyInfo teclaN = Console.ReadKey();
                    break;

                case 7:
                    Console.WriteLine("===== Buscar Agenda por Calle =====");
                    Console.Write("Ingrese código de la agenda: ");
                    string calleB = Console.ReadLine();

                    ObjetoCompleto completo7 = negocio.ObtenerPorCalle(calleB);

                    if (completo7 != null)
                    {
                        Console.WriteLine($"Encontrado: {completo7.Agenda.Dni}, {completo7.Agenda.Apellido}, {completo7.Agenda.Nombre}, {completo7.Agenda.Calle}, {completo7.Agenda.Depto}, {completo7.Agenda.Piso}, {completo7.Agenda.Ciudad}, {completo7.Agenda.Telefono}, {completo7.Agenda.Email}, {completo7.Agenda.CuilCuit}, {completo7.Agenda.FechaDeAlta}, {completo7.Agenda.Estado_Civil}, {completo7.Agenda.Nacionalidad}, {completo7.Agenda.Provincia}, {completo7.Agenda.Codigo_Postal}, {completo7.Agenda.Barrio}, {completo7.Agenda.Telefono_Alternativo}, {completo7.Agenda.RedSocial_IG}, {completo7.Agenda.ProfesionOcupacion}, {completo7.Agenda.Lugar_Trabajo}, {completo7.Agenda.Nivel_Estudios}, {completo7.Agenda.Estado}, {completo7.Agenda.MetodoPago_Preferido}, {completo7.Agenda.ObservacionesNotas}");

                        if (completo7.Cuenta != null)
                        {
                            // datos de CuentaCte
                        }
                    }
                    else
                    {
                        Console.WriteLine("No existe.");
                    }

                    Console.WriteLine("Presiona cualquier tecla para continuar...");
                    ConsoleKeyInfo teclaC = Console.ReadKey();
                    break;

                case 8:
                    Console.WriteLine("Saliendo...");
                    break;

                default:
                    Console.WriteLine("Opción inválida.");
                    break;
            }

            Console.WriteLine();

        } while (opcion != 8);
    }
}